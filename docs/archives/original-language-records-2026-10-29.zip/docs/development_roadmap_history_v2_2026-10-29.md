# MehrChain — نقشه‌راه فعال

آخرین سامان‌دهی: **2026-10-29، Asia/Tehran**.

این فایل مرجع وضعیت و اقدام بعدی است. [قرارداد تحلیل و وایرفریم](ui_ux_discovery_plan.md)
جزئیات خروجی طراحی را تعریف می‌کند. [سوابق پیش از پاک‌سازی](development_roadmap_history_2026-10-29.md)
تمام شرح‌های قبلی، commitها، چک‌لیست‌ها و شواهد انتشار را نگه می‌دارد؛ وضعیت‌های قدیمی
در آن، وضعیت جاری محسوب نمی‌شوند. شمارهٔ T00–T25 و نگاشت issueها تغییر نکرده است.

این بازبینی مستندات است: وضعیت زندهٔ GitHub، Render، دیتابیس و دستگاه‌ها در ۲۹ اکتبر
دوباره بررسی نشده است. وضعیت‌های فنی زیر بر آخرین شاهد ثبت‌شده در مخزن تکیه دارند؛
بازبودن/بسته‌بودن فعلی issueها یا آمادگی انتشار از این جدول نتیجه‌گیری نمی‌شود.

## تصمیم فعلی و کار بعدی

- **ساختار A پروفایل، مبنای ادامهٔ طراحی است.** این ترجیح، تأیید نهایی تمام صفحات یا مجوز پیاده‌سازی نیست.
- رنگ‌های v0.1 و تفاوت زیاد اجزای آن با محصول رد شدند. **رنگ و جزئیات v0.2 هنوز تأیید نشده‌اند.**
- اکنون اولویت بررسی، **T20 و تکمیل وایرفریم T22** است؛ جریان حسابِ T21-UX و صفحات T23/T24 باید در همین سیستم دیده شوند.
- تشخیص فنی T21-D طبق درخواست «اول UI/UX، سپس منطق» فعلاً به بعد از بررسی ساختاری موکول است؛ خطای واقعی نام کاربری همچنان حل‌شده محسوب نمی‌شود.
- T25 اکتشافی و P2 است. کارهای عملیاتی/پذیرش T12–T19 مسیر مستقل دارند؛ وایرفریم جای آن‌ها را نمی‌گیرد.

## قرارداد اجباری برای هر تحلیل دارای UI

**خروجی باید داخل زبان و محیط آشنای خود مهرچین قابل بررسی باشد.**

1. ابتدا صفحهٔ موجود، توکن‌ها و اجزای واقعی مخزن بررسی و مسیر فایل‌های مبنا ثبت شود.
2. وایرفریم از فونت، Lucide، Mero، ناوبری، پوستهٔ موبایل/PWA، فاصله‌ها، کارت‌ها و کنترل‌های فعلی استفاده کند. بازسازی مستقل باید میزان تطابق و موارد شبیه‌سازی‌شده را روشن کند.
3. «وضعیت فعلی» و «پیشنهاد» در **همان قاب، تم، داده و ابعاد** قابل مقایسه باشند. پنل بررسی بیرون برنامه مجاز است؛ خود طرح نباید به یک اپ با زبان بصری نامرتبط تبدیل شود.
4. اگر موضوع تسک تغییر رنگ یا یک جزء است، تغییر پیشنهادی محدود و مشخص باشد؛ بقیهٔ اجزا ثابت بمانند. انتخاب یک ساختار به معنی تأیید رنگ یا رفتارهای دیگر نیست.
5. خروجی شامل تحلیل کوتاه، `index.html` قابل کلیک، مسیرهای رفت/برگشت، حالت‌های مرتبط و چک‌لیست تصمیم باشد؛ فقط تصویر، swatch یا متن کافی نیست.
6. نظر مالک برای **شناسهٔ تسک + نسخه + محدوده** ثبت شود. پس از تأیید همان محدوده، تسک اجرایی مرتبط با معیار پذیرش و وابستگی‌ها ساخته شود؛ نمونهٔ نمایشی، feature تکمیل‌شده نیست.

جزئیات و معیار تحویل در [قرارداد وایرفریم](ui_ux_discovery_plan.md#mandatory-design-system-and-context-contract) است؛ این الزام برای تحلیل‌های UI آینده نیز برقرار است.

## تغییراتی که در v0.2 دیده شد، متعلق به کدام تسک است؟

بستهٔ مشترک: [index.html — v0.2](../design/ux/t22-profile-structure/index.html) ·
[شرح و محدودیت‌ها](../design/ux/t22-profile-structure/README.md) ·
[تصمیم‌ها](../design/ux/t22-profile-structure/decisions.md).

| آنچه دیده شد | مالک اصلی | میزان پوشش فعلی | آنچه هنوز تأیید یا انجام نشده |
| --- | --- | --- | --- |
| پالت پیشنهادی، تم روشن/تیره، نمایش اجزا و توکن‌ها | **T20** | مقایسهٔ اولیهٔ پالت فعلی/پیشنهادی روی اجزای هم‌خانواده | انتخاب نهایی رنگ، ممیزی کامل توکن/کنتراست و نگاشت تغییرات |
| حساب و امنیت، ویرایش/حذف نام کاربری و پیام خطای ذخیره | **T21-UX** زیرمجموعهٔ T21 | جریان اولیه و ذخیرهٔ شبیه‌سازی‌شده | همهٔ حالت‌های availability/conflict/session؛ **T21-D تشخیص API انجام نشده** |
| خلاصهٔ هویت و Mero، خروج فرم‌ها از پروفایل، ورودی‌های مستقل | **T22** | ساختار A برای ادامه ترجیح داده شد؛ نمونهٔ قابل کلیک موجود است | تأیید نسخهٔ نهایی، اندازه‌گیری واقعی اسکرول و پذیرش گوشی/کیبورد |
| کارت خلاصهٔ نشان‌ها ← صفحهٔ نشان‌ها، فیلتر و جزئیات | **T23**؛ جای کارت با T22 | نمونهٔ اولیه و آزمون چیدمان با نشان‌های ساختگی | قرارداد کامل داده/route/deep-link و همهٔ حالت‌ها؛ قواعد کسب جدید پیشنهاد نشده |
| کارت مجموعه‌رنگ ← استودیو، پیش‌نمایش/نام/ذخیره/لغو | **T24**؛ جای کارت با T22 | نمونهٔ اولیهٔ قفل/استودیو و پیش‌نمایش مستقل | گزینهٔ دوم، تمام حالت‌های slot/reward، خطا/بازیابی/reload و تأیید مالک |
| نمایش Home، Chain، Journey، معرفی و فرم عادت | **فقط نمونهٔ زمینه‌ای T20** | نمایش اثر پالت/اجزا در فضای محصول | بازطراحی مستقل یا تغییر منطق این صفحات در این بسته انجام/تأیید نشده |
| نمایش Mero واقعی | مبنای مشترک **T20/T22/T24** | استفاده از مدل موجود برای تطبیق بصری | **T25 را پوشش نمی‌دهد**؛ تعامل شکم و ارزیابی هزینه هنوز شروع نشده |

T01/T04/T06/T11/T16/T17/T18/T19 محدودیت‌ها و رفتارهای موجود را فراهم می‌کنند؛ نمایش
اجزای آن‌ها در نمونه، به معنی اجرای دوباره یا تکمیل پذیرش آن تسک‌ها نیست.

## نوع کار و معنی وضعیت

| نوع | خروجی | چه چیزی آن را کامل نمی‌کند؟ |
| --- | --- | --- |
| تحلیل/طراحی UI | مسئله، وایرفریم در دیزاین‌سیستم، HTML و تصمیم نسخه‌دار | داشتن یک mock یا اجرای موفق HTML |
| تشخیص فنی | علت با شاهد پاک‌سازی‌شده، محدودهٔ خرابی و برنامهٔ اصلاح | شبیه‌سازی ذخیره یا حدس از متن خطا |
| امکان‌سنجی | تجربهٔ قابل مشاهده، هزینه/محدودیت و تصمیم ادامه/ساده‌سازی/تعویق | صرف نمایش Mero یا یک انیمیشن |
| پیاده‌سازی | کد مطابق محدودهٔ توافق‌شده و بررسی‌های مرتبط | تأیید یک ایده یا وجود وایرفریم |
| پذیرش/انتشار | شاهد روی revision، محیط و دستگاه هدف | commit، push، build قدیمی یا نتیجهٔ محیط آزمایشی |

مراحل تحلیل UI: **D0 ثبت‌شده → D1 تحلیل → D2 وایرفریم اولیه → D3 در بازبینی/اصلاح → D4 تأیید محدودهٔ نسخه**.
بعد از D4، کار اجراییِ مرتبط تعریف می‌شود و وضعیت پیاده‌سازی و پذیرش آن جدا ثبت می‌شود.
ترجیح یک گزینه ممکن است بخشی از تصمیم باشد؛ تا محدوده و نسخه تأیید نشوند، کل تسک D4 نیست.

## تسک‌های تحلیل، وایرفریم و امکان‌سنجی

| تسک / issue | نوع و اولویت | وضعیت واقعی | خروجی بعدی و شرط عبور |
| --- | --- | --- | --- |
| **T20** · [#79](https://github.com/farzad-bahadorifar/mehrchain/issues/79) · دیزاین‌سیستم و رنگ | تحلیل + وایرفریم، P1 | **D3**؛ v0.1 رد شد، v0.2 در انتظار بازبینی رنگ | پالت و توکن‌های مشخص روی صفحات ثابت؛ انتخاب نسخه و نگاشت تغییرات |
| **T21** · [#80](https://github.com/farzad-bahadorifar/mehrchain/issues/80) · نام کاربری و حساب | تشخیص فنی + طراحی تعامل، P1 | **UX: D2**؛ **تشخیص: شروع نشده/موکول** | T21-UX: جریان کامل در سیستم فعلی؛ T21-D: شاهد علت واقعی و برنامهٔ اصلاح. این‌ها دو محدودهٔ همان تسک‌اند، نه دو issue جدید |
| **T22** · [#81](https://github.com/farzad-bahadorifar/mehrchain/issues/81) · معماری Profile | تحلیل + وایرفریم، P1 | **D3**؛ A مبنای ادامه، جزئیات نهایی نشده | تکمیل A با T20/T21-UX، مقایسهٔ واقعی دسترسی/اسکرول و تأیید نسخه |
| **T23** · [#82](https://github.com/farzad-bahadorifar/mehrchain/issues/82) · صفحهٔ نشان‌ها | تحلیل + وایرفریم، P1 | **D2**؛ نمونهٔ اولیه موجود، تأیید نشده | جریان کامل Profile ↔ Badges، حالت‌ها و مقیاس‌پذیری با قواعد موجود |
| **T24** · [#83](https://github.com/farzad-bahadorifar/mehrchain/issues/83) · جایزه و استودیوی رنگ | تحلیل + وایرفریم، P1 | **D2**؛ نمونهٔ اولیه موجود، تأیید نشده | دو گزینه در همان سیستم؛ نقشهٔ حالت کامل با قواعد ثابت T06 |
| **T25** · [#84](https://github.com/farzad-bahadorifar/mehrchain/issues/84) · تعامل رنگ شکم Mero | امکان‌سنجی، P2 | **D0**؛ نمونهٔ تعامل ندارد | ابتدا تجربهٔ ساده داخل قاب/Mero فعلی؛ سپس فقط در صورت انتخاب جهت، spike سه‌بعدی و سنجش هزینه |

**ترتیب ادامه:** بازبینی T20 و تکمیل A در T22 با T21-UX → تکمیل T23/T24 در همان
پوسته → ثبت محدوده‌های تأییدشده → تعریف کار اجرایی. T21-D برای حل خطای واقعی باز است
ولی در این مرحلهٔ ساختاری اجرا نمی‌شود. T25 اختیاری است و خودکار مانع v1 نمی‌شود.

## تسک‌های اجرا، عملیات و پذیرش

وضعیت زیر از شواهد قبلی استخراج شده است؛ در این پاک‌سازی هیچ پذیرش جدیدی ثبت نشده.
شرح کامل/چک‌لیست قدیمی در [سوابق](development_roadmap_history_2026-10-29.md) و handoff هر ردیف موجود است.

| تسک / issue | نوع | آخرین وضعیت ثبت‌شده | اقدام/شاهد باقی‌مانده |
| --- | --- | --- | --- |
| T00 · [#55](https://github.com/farzad-bahadorifar/mehrchain/issues/55) · قرارداد timezone ورود | اصلاح + انتشار | رفع blocker ثبت شده | پذیرش کامل ورود واقعی زیر T09؛ [گزارش رخداد](timezone_incident_2026-10-18.md) |
| T01 · [#56](https://github.com/farzad-bahadorifar/mehrchain/issues/56) · پوسته و کارت‌های ساده | پیاده‌سازی | تکمیل ثبت‌شده؛ Mero سه‌بعدی جای جهت static-only قدیمی را گرفته | ماتریس بصری نهایی با T19/T09؛ [handoff](t01_review_handoff.md) |
| T02 · [#57](https://github.com/farzad-bahadorifar/mehrchain/issues/57) · روز و streak هر عادت | منطق + schema | پیاده‌سازی/مهاجرت تأییدشدهٔ تاریخی | مرز روز، دستگاه و رقابت PostgreSQL در پذیرش نهایی؛ [handoff](t02_review_handoff.md) |
| T03 · [#58](https://github.com/farzad-bahadorifar/mehrchain/issues/58) · آرشیو و قطع Chain | منطق + schema | پیاده‌سازی/مهاجرت تأییدشدهٔ تاریخی | سناریوهای چندروزه/restore در T09؛ [handoff](t03_review_handoff.md) |
| T04 · [#59](https://github.com/farzad-bahadorifar/mehrchain/issues/59) · قلب کم‌سروصدا | منطق + UI | تکمیل ثبت‌شده | پذیرش روز/دریافت/تکرار با دو حساب در T09؛ [handoff](t04_review_handoff.md) |
| T05 · [#60](https://github.com/farzad-bahadorifar/mehrchain/issues/60) · دلیل خصوصی قطع | پیاده‌سازی + پذیرش | کد موجود؛ migration با T12 اعمال شده | پذیرش receipt/retry و reconnect؛ [handoff](t05_review_handoff.md) |
| T06 · [#61](https://github.com/farzad-bahadorifar/mehrchain/issues/61) · مجموعه‌رنگ دائمی | منطق + schema + پذیرش | کد موجود؛ migration با T12 اعمال شده | پذیرش حساب واقعی/PWA؛ طراحی T24 قواعد کسب را عوض نمی‌کند؛ [handoff](t06_review_handoff.md) |
| T07 · [#62](https://github.com/farzad-bahadorifar/mehrchain/issues/62) · توضیح قواعد روزانه | اجرای تاریخی با جهت اصلاح‌شده | جهت قدیمی پنل‌های طولانی با تصمیم مالک در T16 جایگزین شده | پنل‌های قدیمی دوباره اجرا نشوند؛ پذیرش رفتار T16؛ [handoff تاریخی](t07_review_handoff.md) |
| T08 · [#63](https://github.com/farzad-bahadorifar/mehrchain/issues/63) · کاهش اصطکاک شروع | پیاده‌سازی + اندازه‌گیری | refresh dedup/probe موجود؛ پذیرش باز | سنجش عملکرد با T15 و شبکهٔ هدف؛ [handoff](t08_review_handoff.md) |
| T09 · [#64](https://github.com/farzad-bahadorifar/mehrchain/issues/64) · پذیرش دو حساب | پذیرش میدانی | پایلوت اولیه انجام شده، پذیرش نهایی باز | مسیرهای واقعی، روز/غیبت، PWA، Android و شواهد revision نهایی |
| T10 · [#66](https://github.com/farzad-bahadorifar/mehrchain/issues/66) · build بک‌اند | اصلاح build | رفع مشکل و انتشار ثبت شده | gate build در نسخه‌های بعد حفظ شود؛ [handoff](t10_release_build_handoff.md) |
| T11 · [#67](https://github.com/farzad-bahadorifar/mehrchain/issues/67) · Journey | پیاده‌سازی UI | refactor ثبت‌شده | پذیرش نهایی نمایش/داده زیر T09؛ نمونهٔ T20 بازطراحی تازه نیست |
| T12 · [#68](https://github.com/farzad-bahadorifar/mehrchain/issues/68) · هم‌ترازی release/schema | عملیات + پذیرش، gate | schema/backend T05/T06 در ۲۱ اکتبر ترمیم شد | بازبینی revision فعلی، frontend/PWA و هر migration واقعاً معوق؛ [شاهد](t12_release_execution_2026-10-21.md) |
| T13 · [#69](https://github.com/farzad-bahadorifar/mehrchain/issues/69) · CI و مسیر APK | اصلاح + بررسی | backend-step شاهد موفق دارد؛ fixtureهای frontend اصلاح شده‌اند | اجرای کامل روی revision منتخب تا artifact APK؛ [شاهد](t12_release_execution_2026-10-21.md) |
| T14 · [#71](https://github.com/farzad-bahadorifar/mehrchain/issues/71) · ایمیل واقعی | پیکربندی + پذیرش | در آخرین ثبت، منتظر دامنه/فرستنده/کلید | ارسال واقعی signup/OTP/reset؛ [handoff](t14_email_setup_handoff.md) |
| T15 · [#72](https://github.com/farzad-bahadorifar/mehrchain/issues/72) · cold start | پیاده‌سازی + سنجش | اصلاح bounded safe-read retry موجود | بررسی idle/warm، گوشی/PWA و failure/retry؛ [handoff](t15_access_recovery_handoff.md) |
| T16 · [#75](https://github.com/farzad-bahadorifar/mehrchain/issues/75) · اصلاحات محصول مالک | پیاده‌سازی + پذیرش | پیاده‌سازی محلی ثبت‌شده | اجرای نهایی minimal UI، Why، حذف مستقیم و collection روی گوشی/PWA؛ [handoff](t16_review_handoff.md) |
| T17 · [#76](https://github.com/farzad-bahadorifar/mehrchain/issues/76) · دسترسی با username | منطق + schema + پذیرش | کد و rehearsal موجود؛ پذیرش تولید باز | migration/checks/delivery و حساب واقعی؛ تشخیص T21 تکرار این پیاده‌سازی نیست؛ [handoff](t17_review_handoff.md) |
| T18 · [#77](https://github.com/farzad-bahadorifar/mehrchain/issues/77) · به‌روزرسانی اختیاری | پیاده‌سازی + انتشار | پیاده‌سازی merged در PR #73 | امضا، metadata و ارتقای واقعی هم‌کلید؛ [handoff](t18_t19_review_handoff.md) |
| T19 · [#78](https://github.com/farzad-bahadorifar/mehrchain/issues/78) · fit و تعامل موبایل | پیاده‌سازی + پذیرش دستگاه | پیاده‌سازی merged در PR #73/#74 | ماتریس واقعی tab/PWA/keyboard/zoom؛ Text size رد شده است؛ [handoff](t18_t19_review_handoff.md) |

## مسیر انتشار؛ مستقل از تأیید وایرفریم

1. T12: revision و schema واقعی را ابتدا بررسی کن؛ migrationهای T05/T06 قبلاً اعمال شده‌اند و نباید صرفاً از روی یادداشت قدیمی تکرار شوند. T17 فقط شاهد rehearsal دارد؛ pending واقعی دوباره تعیین شود.
2. T13/T14: بررسی‌های استاندارد و مسیر APK، سپس ایمیل واقعی. T08/T15: سنجش دسترسی. T16 → T17 → T18 → T19: تکمیل پذیرش اصلاحات ثبت‌شده.
3. T09: پذیرش دو حساب روی candidate مشخص و نسخه‌های هماهنگ frontend/backend/PWA؛ سناریوهای تاریخ/غیبت/حمایت، Google/ایمیل و شکست درخواست جدا ثبت شوند.
4. Android: web build تازه → `cap sync` → بستهٔ امضاشدهٔ candidate با publication خاموش → بررسی certificate/app ID/versionCode/checksum → نصب و ارتقای هم‌کلید روی گوشی. یک build قدیمی نتیجهٔ candidate فعلی نیست.
5. فقط پس از پذیرش و تعیین محدودهٔ انتشار، tag/release رسمی. انتشار `v*` در workflow فعلی می‌تواند انتشار عمومی ایجاد کند؛ tag برای صرفاً تست APK ساخته نشود. [راهنمای امضا](android_signing_guide.md) و [روش migration](database_migration_procedure.md) مرجع‌اند.

تغییرات طراحی فقط با محدودهٔ تأییدشده وارد candidate می‌شوند. هیچ migration، push، tag،
Release یا همگام‌سازی GitHub در این پاک‌سازی اجرا نشده است. اسکریپت‌های قدیمی sync
تعریف‌های تاریخی دارند؛ منبع وضعیت فعلی این roadmap و قرارداد طراحی است، نه اجرای مجدد آن‌ها.

## افزودن تسک تحلیلی بعدی

تسک جدید پس از دریافت موضوع از مالک ثبت شود؛ فعلاً T26 یا issue تازه‌ای ایجاد نشده است.
برای هر موضوع: **مسئله و هدف تصمیم، نوع تحلیل، محدوده/خارج محدوده، صفحه و اجزای موجود،
وابستگی، وضعیت D0–D4، خروجی `index.html` در همان دیزاین‌سیستم، معیار تصمیم و محل ثبت نسخه** مشخص شود.
اگر تحلیل صرفاً فنی است و UI ندارد، شاهد تشخیص جای وایرفریم را می‌گیرد؛ اگر هر بخش UI
دارد، قرارداد وایرفریم بالا برای آن بخش لازم است. جزئیات قالب در انتهای [قرارداد](ui_ux_discovery_plan.md#template-for-future-analysis-tasks) است.

## قواعد پایدار محصول

این بخش از نقشه‌راه قبلی حفظ شده است؛ تغییر ظاهر مجوز تغییر آن‌ها نیست.

People should have room to grow through choice, small steps and real support. A solo user gets a complete experience; Chain is optional. Keep progress private, avoid comparison and preserve earlier effort after absence.

- **Daily habits:** Endless or Custom N completed days. A new calendar date opens the next completion; creating a habit at 08:00 must not impose an 08:00 reset.
- **Per-habit streak:** no global streak. After one missed date, the next completion starts at 1; cumulative progress remains.
- **Two missed days:** archive that habit after two fully missed consecutive dates and disconnect its attached chains. Opening the app or completing another habit does not count. Restore preserves history and requires a new invitation to reconnect.
- **Quiet support:** one heart action, received support without names, a number when multiple hearts arrive. No reaction feed or partner streak comparison.
- **Respectful disconnect:** ask a reason, preview what is shared and deliver it privately to the partner. Include a non-disclosing choice.
- **Mero:** fixed name. The current implementation uses adaptive Three.js rendering with animation and static/fallback behavior; the original static-only T01 direction has been superseded in code by `31e965f` and `657eab1`. T06 applies the selected named color to the existing 3D/fallback mascot, with permanent slots and optional habit/accepted-Chain progress paths. Preserve motion/device safeguards and keep names attached to colors.
- **Minimal UI:** one primary action per card, one completion check, secondary information in details. Desktop PWA content stays compact even in a maximized window.
- **Owner correction (October 21; clarified October 22):** remove the recently added expandable rule/help panels and redundant navigation banners/links. Preserve the established onboarding introduction: why walk together, the meaning of MehrChain and how Chains work, including their cards and copy. Keep necessary labels, validation, save errors and confirmation consequences. The optional habit Why input is always visible in habit forms, starts empty and uses a placeholder; it must not be hidden in an optional accordion or populated with sample motivation.
- **Personal motivation:** only a reason deliberately entered by the user qualifies for the pre-deletion reflection and any future motivation reminder. Blank/sample values do not qualify. Habit Why is private and distinct from a Chain disconnect explanation; future Chain behavior must not expose it to partners implicitly.
- **Removal choices:** direct permanent deletion must be available from the active habit on Home without first archiving it. Show the user's custom Why before confirming deletion. Keep cancellation and archive as separate choices; automatic two-missed-day archiving and history-preserving restore remain unchanged.
- **Honest feedback:** confirm saves before showing success; preserve input and allow retry on failure. Use short English copy, accessible controls and restrained feedback.

Implemented in T02/T03: persisted account IANA timezone; no missed-day penalty for a partial creation/restore date; Custom counts completed days; finite goals offer Continue or Archive when reached. Existing accounts/history retain UTC, and signing in or changing device timezone does not change an account's zone. The October 18 migration preserved those historical fields and UTC defaults. On October 20 the owner selected T06 scenario C: first earn a permanent color slot through one 21-day habit streak, then earn more shared slots through completed account dates or distinct accepted Chain partners. The precise contract is preserved in the historical T06 section (development_roadmap_history_2026-10-29.md) and its OpenSpec delta; this is not a global streak or an obligation to connect.

Implemented in T04: one sender per recipient habit per recipient account date, regardless of multiple links. A send is idempotent and never toggles off on retry. Disconnect/archive/private changes clear visible support, but do not refund that day's allowance; reconnecting the same day cannot revive the old support. Sent state follows the partner habit's calendar; own received counts follow the own habit's calendar. T05 retains this distinction: disconnect receipts do not read or modify the daily allowance ledger.

Implemented in T05 (`ed38dd6`): an explicit manual reason, Cancel, private preview and optional 500-character plain-text explanation; one durable partner receipt in the reciprocal-disconnect transaction; generation tokens for safe reconnect/retry; neutral lifecycle receipts; a recipient-only pending inbox with explicit saved dismissal. Prefer not to share stores no explanation. These are implementation facts from source review, not executed acceptance results.
